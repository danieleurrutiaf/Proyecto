from django.contrib import admin
from django.contrib import admin
from .models import Genero, Usuario
# Register your models here.
admin.site.register(Genero)
admin.site.register(Usuario)