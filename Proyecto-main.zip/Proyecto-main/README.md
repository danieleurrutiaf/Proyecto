Aca se guardara informacion de los registros de cada integrante 
Formato "Nombre - - DD/MM - - "Mensaje descriptivo del push""


------------------------------------------------------------------------------------



Sebastian - - 12/JUN -- "Se cambio el tamaño de la hoja css"

Daniel - - 12/JUN - - "Se arreglaron los errores pertenecientes al header y footer "

Felipe - - 16/JUN - - "Se agrego funcion para la barra buscadora la cual debera buscar los servicios y mostrar el senalado"


Sebastian - - 13/JUN - - "-Primer cambio: Se ajusto hover del navbar
                         -Segundo cambio: Se arreglo funcionamiento del boton de carrito
                         -Tercer cambio: Se instalo el bloque en el html proyecto 1"

Sebastian - - 13/JUN - - " Se crearon los html "Servicios" y se guardaron en la carpeta "Servicios" que esta dentro del template, cabe destacar que se modifico el url.py, view.py y las demas rutas pertinentes"

Sebastian - - 13/JUN - - "Se creo el super usuario Admin y las tablas correspondientes de Usuario y genero, por el momento se probara en el html noticias, mas adelante se creara el respectivo html"

Daniel - - 15/JUN - - "Se creo el crud en el html "noticias" por el momento"

Sebastian - - 15/JUN - - "Se crearon los html de Usuarios (add, list y edit)
                          Se creo el form para agregar Usuarios, pero tiene problemas a la hora de hacer su funcion"
                          Se cambio el crud al footer (Se llama "Usuarios")
                          
Sebastian - - 15/JUN - - "Pase 3 horas intentando arreglar el codigo... veo la diapo de la actividad 3.4 donde muestra hacerlo de una manera mas senclla, ojala funcione jeje"

Sebastian - - 16/JUN - - "Agregar y eliminar usuarios esta listo, falta hacer el modificar, pero lo hago manana pq ya son las 4 am jeje, tambien manana hago los estilos para que se vea decente"

Sebastian - - 16JUN - - "Estan todas las funciones y html de listar, agregar, eliminar y modificar listos... en el proximo commit ya estaran con los estilos listos"

Sebastian - - 17JUN - - "Estan todos los estilos listos, ahora voy a hacer el login de la pagina, aunque primero voy pensar en la logica de ese mismo"

Felipe - - 19JUN - - "Se integro un login con autentificacion Django"
